-- MariaDB dump 10.19  Distrib 10.6.11-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: forklift
-- ------------------------------------------------------
-- Server version	10.6.11-MariaDB-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `data_pengecekan`
--

DROP TABLE IF EXISTS `data_pengecekan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_pengecekan` (
  `id` varchar(9) NOT NULL,
  `id_forklift` varchar(6) NOT NULL,
  `nama_driver` varchar(25) NOT NULL,
  `shift_driver` int(5) NOT NULL,
  `status` varchar(20) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data_pengecekan`
--

LOCK TABLES `data_pengecekan` WRITE;
/*!40000 ALTER TABLE `data_pengecekan` DISABLE KEYS */;
INSERT INTO `data_pengecekan` VALUES ('290684458','A1','Agung',0,'Kurang Baik','2023-01-09 09:16:02'),('420660614','A2','Irfan',0,'Kurang Baik','2023-01-09 09:28:47'),('719935690','A2','Irfan',0,'Kurang Baik','2023-01-09 09:26:12'),('908634450','A1','Agung',0,'Kurang Baik','2023-01-09 09:15:45');
/*!40000 ALTER TABLE `data_pengecekan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data_pengguna`
--

DROP TABLE IF EXISTS `data_pengguna`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_pengguna` (
  `id` varchar(6) NOT NULL,
  `nama` varchar(25) NOT NULL,
  `kata_sandi` char(60) NOT NULL,
  `role` varchar(8) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data_pengguna`
--

LOCK TABLES `data_pengguna` WRITE;
/*!40000 ALTER TABLE `data_pengguna` DISABLE KEYS */;
INSERT INTO `data_pengguna` VALUES ('000000','forkliftgajahtunggal','$2b$10$QFHW0R.n0juNQdtZ9aGg/./nNoOQJRByG0k8ghoTTbsjPYjs2LUDS','driver'),('111111','bengkelgajahtunggal','$2b$10$yymq33snkKGAzJyU85TwIOGax/eaI/aTwC52apzrCBgockRZnyMJa','mechanic'),('200884','irfanhidayat','$2b$10$gDg3/FOcIX12te7ZevOgW.isrD.l/DiWAxtymJJvQ7K5jgZt6Jviq','leader');
/*!40000 ALTER TABLE `data_pengguna` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detail_pengecekan`
--

DROP TABLE IF EXISTS `detail_pengecekan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detail_pengecekan` (
  `id` varchar(9) NOT NULL,
  `ban` varchar(50) DEFAULT NULL,
  `fork` varchar(50) DEFAULT NULL,
  `seat_belt` varchar(50) DEFAULT NULL,
  `lampu_depan_belakang` varchar(50) DEFAULT NULL,
  `rem_tangan_kaki` varchar(50) DEFAULT NULL,
  `lampu_sein` varchar(50) DEFAULT NULL,
  `klakson` varchar(50) DEFAULT NULL,
  `alarm_mundur` varchar(50) DEFAULT NULL,
  `lampu_sirine` varchar(50) DEFAULT NULL,
  `tempat_duduk` varchar(50) DEFAULT NULL,
  `kaca_spion` varchar(50) DEFAULT NULL,
  `apar` varchar(50) DEFAULT NULL,
  `oli` varchar(50) DEFAULT NULL,
  `kebersihan` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `detail_pengecekan_ibfk_1` FOREIGN KEY (`id`) REFERENCES `data_pengecekan` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detail_pengecekan`
--

LOCK TABLES `detail_pengecekan` WRITE;
/*!40000 ALTER TABLE `detail_pengecekan` DISABLE KEYS */;
INSERT INTO `detail_pengecekan` VALUES ('290684458','','','','Lampu mati','','','','','','','','','',''),('420660614','','','','Kodokkk','','','','','','','','','',''),('719935690','','','','Kodokkk','','','','','','','','','',''),('908634450','','','','Lampu mati','','','','','','','','','','');
/*!40000 ALTER TABLE `detail_pengecekan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `status_pengecekan`
--

DROP TABLE IF EXISTS `status_pengecekan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `status_pengecekan` (
  `id` varchar(9) NOT NULL,
  `ban` int(1) NOT NULL DEFAULT 1,
  `fork` int(1) NOT NULL DEFAULT 1,
  `seat_belt` int(1) NOT NULL DEFAULT 1,
  `lampu_depan_belakang` int(1) NOT NULL DEFAULT 1,
  `rem_tangan_kaki` int(1) NOT NULL DEFAULT 1,
  `lampu_sein` int(1) NOT NULL DEFAULT 1,
  `klakson` int(1) NOT NULL DEFAULT 1,
  `alarm_mundur` int(1) NOT NULL DEFAULT 1,
  `lampu_sirine` int(1) NOT NULL DEFAULT 1,
  `tempat_duduk` int(1) NOT NULL DEFAULT 1,
  `kaca_spion` int(1) NOT NULL DEFAULT 1,
  `apar` int(1) NOT NULL DEFAULT 1,
  `oli` int(1) NOT NULL DEFAULT 1,
  `kebersihan` int(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  CONSTRAINT `status_pengecekan_ibfk_1` FOREIGN KEY (`id`) REFERENCES `data_pengecekan` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `status_pengecekan`
--

LOCK TABLES `status_pengecekan` WRITE;
/*!40000 ALTER TABLE `status_pengecekan` DISABLE KEYS */;
/*!40000 ALTER TABLE `status_pengecekan` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-15  3:39:25
